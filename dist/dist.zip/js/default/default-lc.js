$(document).ready(function() {
	$('.js-example-basic-single').select2({
		minimumResultsForSearch: -1,
		theme: "my",
	});
});
